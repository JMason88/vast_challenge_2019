var allData = MedicionesEstaticos 

// Draw bar chart
function setUpCanvas() {

    var margin = {"top": 20,"right": 20,"bottom": 30,"left": 40};

    var canvas = d3.select("body")
                   .append("svg")
                   .attr("width",1000)
                   .attr("height",500)
                   .attr("margin",margin)
                   .style("border", "1px solid black");

    var width = canvas.attr("width") - margin - margin;
    var height = canvas.attr("height") - margin- margin;

    var xScale = d3.scaleLinear()
                   .domain([0,allData.length])
                   .range([0,width]);

    var max_y = d3.max(allData, function(d) {return +d.cantidad; } );

    var yScale = d3.scaleLinear()
                   .domain([0,max_y])
                   .range([height,0]);

    var chartGroup = canvas.append("g")
                           .attr("transform","translate(" + margin.left + "," + margin.top + ")"); 
    


    var x_axisGroup = chartGroup.append("g")
                                .attr("transform","translate(0,"+height+")")
                                .call(d3.axisBottom(xScale).ticks());

    var y_axisGroup = chartGroup.append("g")
                                .call(d3.axisLeft(yScale));
                                
    var barsPlot = chartGroup.selectAll(".bar")
                             .data(allData)
                             .enter()
                             .append("rect")
                             .attr("class","bar")
                             .attr("x", function(d,i) { return xScale(i); })
                             .attr("y", function(d)   { return yScale(d.cantidad);} )
                             .attr("width", 60)
                             .attr("height",function(d) { return height - yScale(d.cantidad); });
                             


    console.log(allData.length)

}

// Convert data
function conversor(d) {
    d.cantidad = +d.cantidad;
    delete d.estacion;
    d.color = "3";
    return d;
}

// Load data
function loadData()
{
    d3.csv("http://localhost:8000/data/jugo.csv", function(data){
        allData.push(conversor(data))

    }).then( function() { 
        console.log("Data loaded!!");
        setUpCanvas();
    });

}

// Open data file
$(document).ready(loadData); 