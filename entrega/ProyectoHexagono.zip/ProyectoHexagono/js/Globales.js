// JavaScript source code
var Lista = [];

var ListaPuntosInteres = [
    ['Hospital', 0.180960, -119.959400],
    ['Hospital', 0.153120, -119.915900],
    ['Hospital', 0.151090, -119.909520],
    ['Hospital', 0.121800, -119.904300],
    ['Hospital', 0.134560, -119.883420],
    ['Hospital', 0.182990, -119.855580],
    ['Hospital', 0.041470, -119.828610],
    ['Hospital', 0.065250, -119.744800],
    ['CentralNuclear', 0.162679, -119.784825]
];
var ListaEstaticos=[];

//La llena GeoCoor
var scaleX;
//La llena GeoCoor
var scaleY;

var PrefijoEstaticos = '';


